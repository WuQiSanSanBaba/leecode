## form-generator

github 地址：https://github.com/JakHuang/form-generator

* generator
* parser
* render
* tinymce

## bpmn-process-designer

github 地址：https://github.com/miyuesc/bpmn-process-designer

* bpmnProcessDesigner

TODO 目前存在的问题，如果选择 activiti 类型时，因为不支持内置表单的设计，所以会报 Error: unknown type activiti:FormData 错误。具体可见 https://github.com/miyuesc/bpmn-process-designer/issues/16 。

另外几个流程设计器的选型：

* https://gitee.com/jimlow/vue-bpmn 相比差一些，已经停止维护，不算推荐。
* https://github.com/GoldSubmarine/workflow-bpmn-modeler 仅支持 flowable 流程引擎。如果只考虑 flowable 的话，也是非常不错的选择。