/**
 * 针对 XSS 的基础封装
 *
 * XSS 说明：https://tech.meituan.com/2018/09/27/fe-security.html
 */
package cn.iocoder.yudao.framework.xss;
