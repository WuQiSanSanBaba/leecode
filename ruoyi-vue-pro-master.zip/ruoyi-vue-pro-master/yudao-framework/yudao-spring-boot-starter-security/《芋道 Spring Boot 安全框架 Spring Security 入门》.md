* 芋道 Spring Security 入门：<http://www.iocoder.cn/Spring-Boot/Spring-Security/?yudao>
* Spring Security 基本概念：<http://www.iocoder.cn/Fight/Spring-Security-4-1-0-Basic-concept-description/?yudao>
