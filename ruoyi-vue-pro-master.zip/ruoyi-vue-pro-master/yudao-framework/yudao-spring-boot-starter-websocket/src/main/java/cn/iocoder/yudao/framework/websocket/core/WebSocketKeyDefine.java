package cn.iocoder.yudao.framework.websocket.core;


import lombok.Data;

@Data
public class WebSocketKeyDefine {
    public static final String LOGIN_USER ="LOGIN_USER";
}
