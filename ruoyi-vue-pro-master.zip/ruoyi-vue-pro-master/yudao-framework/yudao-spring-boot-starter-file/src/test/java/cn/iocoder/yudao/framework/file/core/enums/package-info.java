/**
 * 占位，避免 package 无法提交到 Git 仓库
 */
package cn.iocoder.yudao.framework.file.core.enums;
