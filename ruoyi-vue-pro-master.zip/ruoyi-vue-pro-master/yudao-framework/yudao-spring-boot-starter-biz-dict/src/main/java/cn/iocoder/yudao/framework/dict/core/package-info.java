/**
 * 占位
 */
package cn.iocoder.yudao.framework.dict.core;
