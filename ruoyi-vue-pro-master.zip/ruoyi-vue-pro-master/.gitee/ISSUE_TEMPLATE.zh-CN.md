碰到问题，请在 <https://gitee.com/zhijiantianya/ruoyi-vue-pro/issues> 搜索是否存在相似的 issue。

不按照模板提交的 issue，会被系统自动删除。

### 基本信息

- ruoyi-vue-pro 版本：
- 操作系统：
- 数据库：

### 你猜测可能的原因

（必填）我花费了 2-4 小时自查，发现可能的原因是：xxxxxx

### 复现步骤

第一步，

第二步，

第三步，

### 报错信息

带上必要的截图
